"""
训练脚本：读取 corpus.txt，训练单向 Transformer 语言模型。

低配电脑建议:
- 保持 batch_size、seq_len、d_model 较小
- 没有 GPU 也能跑，只是会慢一些
"""

import os
import pickle

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset

from model import TransformerLM


class TextDataset(Dataset):
    """
    把长文本切成很多 (输入, 目标) 样本。

    例如 seq_len=4:
        输入 x: "我爱中国"  -> [我, 爱, 中, 国]
        目标 y: "爱中国。"  -> [爱, 中, 国, 。]   (整体右移一位)
    """

    def __init__(self, text: str, char2idx: dict, seq_len: int = 32):
        self.seq_len = seq_len
        # 只保留词表里有的字符，避免未知字符报错
        self.data = [char2idx[c] for c in text if c in char2idx]

    def __len__(self) -> int:
        # 文本长度不够 seq_len 时，返回 0，DataLoader 会为空
        return max(0, len(self.data) - self.seq_len)

    def __getitem__(self, idx: int):
        chunk = self.data[idx : idx + self.seq_len + 1]
        x = chunk[:-1]
        y = chunk[1:]
        return torch.tensor(x, dtype=torch.long), torch.tensor(y, dtype=torch.long)


def build_vocab(text: str):
    """从语料构建字符级词表。"""
    chars = sorted(set(text))
    char2idx = {ch: i for i, ch in enumerate(chars)}
    idx2char = {i: ch for ch, i in char2idx.items()}
    return char2idx, idx2char


def train(
    epochs: int = 30,
    batch_size: int = 8,
    seq_len: int = 32,
    d_model: int = 64,
    nhead: int = 4,
    num_layers: int = 2,
    dim_feedforward: int = 32,
    learning_rate: float = 0.001,
    print_every: int = 5,
):
    """主训练流程。"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    corpus_path = os.path.join(base_dir, "corpus.txt")

    # ---------- 1. 读取语料 ----------
    print(f"读取语料: {corpus_path}")
    with open(corpus_path, "r", encoding="utf-8") as f:
        text = f.read()
    print(f"语料字符数: {len(text)}")

    # ---------- 2. 构建词表 ----------
    char2idx, idx2char = build_vocab(text)
    vocab_size = len(char2idx)
    print(f"词表大小: {vocab_size}")

    # ---------- 3. 设备选择 ----------
    # 低配电脑通常只有 CPU；有 GPU 会自动使用
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")

    # ---------- 4. 数据与模型 ----------
    dataset = TextDataset(text, char2idx, seq_len=seq_len)
    if len(dataset) == 0:
        raise ValueError("语料太短，请增加 corpus.txt 内容或减小 seq_len")

    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,  # 每个 epoch 随机打乱，有助于训练
        drop_last=True,  # 丢弃最后不足一个 batch 的数据，避免 batch 大小不一致
    )

    model = TransformerLM(
        vocab_size=vocab_size,
        d_model=d_model,
        nhead=nhead,
        num_layers=num_layers,
        dim_feedforward=dim_feedforward,
    ).to(device)

    param_count = sum(p.numel() for p in model.parameters())
    print(f"模型参数量: {param_count:,} （已为小模型配置）")

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    # ---------- 5. 训练循环 ----------
    model.train()
    print("\n开始训练...")
    for epoch in range(1, epochs + 1):
        total_loss = 0.0
        batch_count = 0

        for x, y in dataloader:
            x, y = x.to(device), y.to(device)

            optimizer.zero_grad()
            logits = model(x)  # [batch, seq_len, vocab_size]

            # CrossEntropyLoss 要求:
            #   预测: [N, C]   N = batch*seq_len, C = vocab_size
            #   标签: [N]
            loss = criterion(
                logits.reshape(-1, vocab_size),
                y.reshape(-1),
            )

            loss.backward()
            optimizer.step()

            total_loss += loss.item()
            batch_count += 1

        avg_loss = total_loss / max(batch_count, 1)
        if epoch % print_every == 0 or epoch == 1 or epoch == epochs:
            print(f"Epoch [{epoch:3d}/{epochs}]  平均 Loss: {avg_loss:.4f}")

    # ---------- 6. 保存模型 ----------
    model_path = os.path.join(base_dir, "transformer_lm.pth")
    vocab_path = os.path.join(base_dir, "vocab.pkl")

    checkpoint = {
        "model_state_dict": model.state_dict(),
        "char2idx": char2idx,
        "idx2char": idx2char,
        "vocab_size": vocab_size,
        "d_model": d_model,
        "nhead": nhead,
        "num_layers": num_layers,
        "dim_feedforward": dim_feedforward,
        "seq_len": seq_len,
    }
    torch.save(checkpoint, model_path)

    with open(vocab_path, "wb") as f:
        pickle.dump({"char2idx": char2idx, "idx2char": idx2char}, f)

    print(f"\n训练完成！")
    print(f"模型权重: {model_path}")
    print(f"词表文件: {vocab_path}")
    return model_path


if __name__ == "__main__":
    # 低配友好默认值；想更快可先改 epochs=10 做试验
    train(
        epochs=30,
        batch_size=16,
        seq_len=32,
        d_model=64,
        nhead=4,
        num_layers=2,
        dim_feedforward=256,
        learning_rate=0.001,
        print_every=5,
    )
