"""
文本生成脚本：加载训练好的模型，根据开头文字续写。

生成策略：贪心 (temperature=0) 或随机采样 (temperature>0)。
"""

import os
from typing import Optional

import torch
import torch.nn.functional as F

from model import TransformerLM


def load_model(
    model_path: Optional[str] = None,
    device: Optional[torch.device] = None,
):
    """
    加载模型和词表。

    返回: (model, char2idx, idx2char, seq_len)
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    if model_path is None:
        model_path = os.path.join(base_dir, "transformer_lm.pth")

    if not os.path.exists(model_path):
        raise FileNotFoundError(
            f"找不到模型文件: {model_path}\n请先运行: python train.py"
        )

    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    checkpoint = torch.load(model_path, map_location=device)

    model = TransformerLM(
        vocab_size=checkpoint["vocab_size"],
        d_model=checkpoint["d_model"],
        nhead=checkpoint.get("nhead", 4),
        num_layers=checkpoint.get("num_layers", 2),
        dim_feedforward=checkpoint.get("dim_feedforward", 256),
    ).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    char2idx = checkpoint["char2idx"]
    idx2char = checkpoint["idx2char"]
    seq_len = checkpoint.get("seq_len", 32)

    return model, char2idx, idx2char, seq_len, device


def encode_text(text: str, char2idx: dict) -> list[int]:
    """把字符串转成 ID 列表，跳过词表中没有的字符。"""
    return [char2idx[c] for c in text if c in char2idx]


def generate(
    start_str: str,
    gen_len: int = 50,
    temperature: float = 0.8,
    model_path: Optional[str] = None,
) -> str:
    """
    根据开头续写文本。

    参数:
        start_str:   开头文字，例如 "黄金"
        gen_len:     最多再生成多少个字符
        temperature: 采样温度
                     - 越小越保守（接近选概率最大的字）
                     - 越大越随机
        model_path:  模型路径，默认使用当前目录下的 transformer_lm.pth
    """
    model, char2idx, idx2char, max_context, device = load_model(model_path)

    input_ids = encode_text(start_str, char2idx)
    if not input_ids:
        raise ValueError(
            f"开头 '{start_str}' 中的字符都不在词表里，请换 corpus.txt 里出现过的字"
        )

    generated = start_str
    input_tensor = torch.tensor([input_ids], dtype=torch.long, device=device)

    with torch.no_grad():
        for _ in range(gen_len):
            # 生成时上下文太长会拖慢速度，只保留最后 max_context 个 token
            if input_tensor.size(1) > max_context:
                input_tensor = input_tensor[:, -max_context:]

            logits = model(input_tensor)
            last_logits = logits[0, -1, :] / max(temperature, 1e-6)

            probs = F.softmax(last_logits, dim=-1)
            next_id = torch.multinomial(probs, num_samples=1).item()
            next_char = idx2char[next_id]

            generated += next_char

            next_token = torch.tensor([[next_id]], dtype=torch.long, device=device)
            input_tensor = torch.cat([input_tensor, next_token], dim=1)

    return generated


if __name__ == "__main__":
    # 使用语料里常见的开头做演示
    demo_seeds = ["黄金", "中国", "期货", "市场"]

    print("=" * 50)
    print("Transformer 单向语言模型 - 文本生成演示")
    print("=" * 50)

    for seed in demo_seeds:
        try:
            result = generate(seed, gen_len=30, temperature=0.8)
            print(f"\n输入: {seed}")
            print(f"生成: {result}")
        except FileNotFoundError as e:
            print(e)
            break
        except ValueError as e:
            print(f"跳过 '{seed}': {e}")
