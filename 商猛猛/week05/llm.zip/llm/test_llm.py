"""
完整测试代码：验证模型、数据集、训练流程和文本生成。

运行方式:
    cd transformer/llm
    python test_llm.py              # 运行全部单元测试
    python test_llm.py --quick      # 快速训练 2 个 epoch 并试生成
    python test_llm.py --interactive  # 交互式输入开头续写
"""

import argparse
import os
import shutil
import sys
import unittest

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from generate import encode_text, generate
from model import TransformerLM
from train import TextDataset, build_vocab, train


class TestTransformerLM(unittest.TestCase):
    """测试模型结构与前向传播。"""

    def setUp(self):
        self.vocab_size = 20
        self.batch_size = 2
        self.seq_len = 8
        self.model = TransformerLM(
            vocab_size=self.vocab_size,
            d_model=32,
            nhead=4,
            num_layers=1,
            dim_feedforward=64,
        )

    def test_forward_shape(self):
        x = torch.randint(0, self.vocab_size, (self.batch_size, self.seq_len))
        logits = self.model(x)
        self.assertEqual(
            logits.shape,
            (self.batch_size, self.seq_len, self.vocab_size),
        )

    def test_causal_mask_is_upper_triangular(self):
        mask = TransformerLM.generate_causal_mask(4, torch.device("cpu"))
        self.assertEqual(mask[0, 0].item(), 0.0)
        self.assertTrue(torch.isinf(mask[0, 1]))
        self.assertTrue(torch.isinf(mask[0, 3]))


class TestTextDataset(unittest.TestCase):
    """测试数据集切分是否正确。"""

    def test_dataset_shift_by_one(self):
        text = "abcdefgh"
        char2idx = {c: i for i, c in enumerate(text)}
        dataset = TextDataset(text, char2idx, seq_len=4)

        x, y = dataset[0]
        self.assertEqual(x.tolist(), [0, 1, 2, 3])
        self.assertEqual(y.tolist(), [1, 2, 3, 4])

    def test_dataset_length(self):
        text = "123456789"
        char2idx = {c: i for i, c in enumerate(text)}
        dataset = TextDataset(text, char2idx, seq_len=3)
        self.assertEqual(len(dataset), len(text) - 3)


class TestBuildVocab(unittest.TestCase):
    def test_unique_chars(self):
        text = "aabbc"
        char2idx, idx2char = build_vocab(text)
        self.assertEqual(len(char2idx), 3)
        self.assertEqual(idx2char[char2idx["a"]], "a")


class TestEncodeText(unittest.TestCase):
    def test_skip_unknown_chars(self):
        char2idx = {"你": 0, "好": 1}
        ids = encode_text("你X好", char2idx)
        self.assertEqual(ids, [0, 1])


def run_quick_end_to_end():
    """
    端到端快速测试：
    1) 临时用语料前 3000 字替换 corpus.txt
    2) 训练 2 个 epoch
    3) 试生成
    4) 恢复原 corpus.txt
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    corpus_path = os.path.join(base_dir, "corpus.txt")
    backup_path = corpus_path + ".bak"

    with open(corpus_path, "r", encoding="utf-8") as f:
        full_text = f.read()
    mini_text = full_text[:3000]

    shutil.copy(corpus_path, backup_path)
    try:
        with open(corpus_path, "w", encoding="utf-8") as f:
            f.write(mini_text)

        print("\n[快速端到端测试] 开始迷你训练 (2 epochs)...")
        model_path = train(
            epochs=2,
            batch_size=8,
            seq_len=16,
            d_model=32,
            nhead=4,
            num_layers=1,
            dim_feedforward=64,
            print_every=1,
        )

        seed = mini_text[:2]
        result = generate(seed, gen_len=20, model_path=model_path, temperature=0.9)
        print(f"\n输入: {seed}")
        print(f"生成: {result}")
        print("\n[快速端到端测试] 通过 ✓")
    finally:
        if os.path.exists(backup_path):
            shutil.move(backup_path, corpus_path)


def run_interactive():
    """交互式测试：手动输入开头，查看续写结果。"""
    model_path = os.path.join(os.path.dirname(__file__), "transformer_lm.pth")
    if not os.path.exists(model_path):
        print("未找到 transformer_lm.pth，请先运行: python train.py")
        return

    print("=" * 45)
    print("交互式文本生成（输入 quit 退出）")
    print("=" * 45)

    while True:
        seed = input("\n请输入开头文字: ").strip()
        if seed.lower() in {"quit", "exit", "q"}:
            break
        if not seed:
            continue

        try:
            length = input("生成长度 (默认 30): ").strip()
            gen_len = int(length) if length else 30
            result = generate(seed, gen_len=gen_len, temperature=0.8)
            print("\n--- 生成结果 ---")
            print(result)
        except Exception as exc:
            print(f"出错: {exc}")


def run_loss_decreases_smoke_test():
    """冒烟测试：在小数据上 loss 应该能下降。"""
    text = "机器学习很有趣。" * 50
    char2idx, _ = build_vocab(text)
    dataset = TextDataset(text, char2idx, seq_len=8)
    loader = DataLoader(dataset, batch_size=4, shuffle=True)

    model = TransformerLM(
        vocab_size=len(char2idx),
        d_model=32,
        nhead=4,
        num_layers=1,
        dim_feedforward=64,
    )
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    losses = []
    model.train()
    for _ in range(5):
        total = 0.0
        count = 0
        for x, y in loader:
            optimizer.zero_grad()
            logits = model(x)
            loss = criterion(logits.reshape(-1, len(char2idx)), y.reshape(-1))
            loss.backward()
            optimizer.step()
            total += loss.item()
            count += 1
        losses.append(total / max(count, 1))

    print(f"\n[Loss 冒烟测试] 5 步 loss: {[round(v, 3) for v in losses]}")
    assert losses[-1] < losses[0], "loss 没有下降，模型可能有问题"
    print("[Loss 冒烟测试] 通过 ✓")


def main():
    parser = argparse.ArgumentParser(description="Transformer LM 测试")
    parser.add_argument("--quick", action="store_true", help="快速端到端训练+生成")
    parser.add_argument(
        "--interactive", action="store_true", help="交互式生成测试"
    )
    args = parser.parse_args()

    if args.interactive:
        run_interactive()
        return

    if args.quick:
        run_quick_end_to_end()
        return

    # 默认：跑 unittest + loss 冒烟测试
    print("运行单元测试...")
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2).run(suite)

    run_loss_decreases_smoke_test()

    if result.wasSuccessful():
        print("\n全部测试通过 ✓")
        print("\n下一步:")
        print("  1. python train.py      # 正式训练")
        print("  2. python generate.py   # 批量演示生成")
        print("  3. python test_llm.py --interactive")
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
