"""
交互式文本生成：输入开头文字，模型自动续写。

用法:
    cd transformer/llm
    python interactive.py
"""

import os
import sys

from generate import generate


def main():
    model_path = os.path.join(os.path.dirname(__file__), "transformer_lm.pth")
    if not os.path.exists(model_path):
        print("还没有训练好的模型！请先运行: python train.py")
        sys.exit(1)

    print("=" * 50)
    print("  Transformer 语言模型 - 交互式续写")
    print("=" * 50)
    print("说明:")
    print("  - 输入开头文字，按回车即可续写")
    print("  - 输入 quit 退出")
    print("  - 开头尽量用 corpus.txt 里出现过的字")
    print("=" * 50)

    while True:
        print()
        seed = input("请输入开头文字 >>> ").strip()
        if seed.lower() in {"quit", "exit", "q"}:
            print("再见！")
            break
        if not seed:
            continue

        length_str = input("续写长度 (默认 40，直接回车即可) >>> ").strip()
        gen_len = 40
        if length_str:
            try:
                gen_len = max(1, int(length_str))
            except ValueError:
                print("长度无效，使用默认 40")

        try:
            print("\n生成中...\n")
            result = generate(seed, gen_len=gen_len, temperature=0.8)
            print("--- 生成结果 ---")
            print(result)
            print("-" * 30)
        except ValueError as exc:
            print(f"提示: {exc}")
        except Exception as exc:
            print(f"出错: {exc}")


if __name__ == "__main__":
    main()
