"""
单向 Transformer 语言模型 (Causal Language Model)

原理简述：
- 语言模型的任务是：给定前面的文字，预测下一个字是什么。
- "单向" 指模型只能看到当前位置左边的字，不能偷看右边的字（因果掩码）。
- 这和 GPT 的结构类似，本质是 Transformer Decoder。
"""

import math

import torch
import torch.nn as nn


class PositionalEncoding(nn.Module):
    """
    位置编码层。

    Transformer 本身不感知顺序（"我 爱 你" 和 "你 爱 我" 对注意力来说差不多），
    所以需要额外加入位置信息，让模型知道每个字在句子中的位置。
    """

    def __init__(self, d_model: int, max_len: int = 5000):
        """
        参数:
            d_model: 每个字的向量维度
            max_len: 支持的最大序列长度
        """
        super().__init__()

        # pe 形状: [max_len, d_model]
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)

        # 不同维度使用不同频率的正弦/余弦，形成唯一的位置指纹
        div_term = torch.exp(
            torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)

        # 增加 batch 维度 -> [1, max_len, d_model]
        pe = pe.unsqueeze(0)

        # register_buffer: 保存常量，不参与训练，但会随模型一起保存/加载
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        输入 x 形状: [batch_size, seq_len, d_model]
        输出: 原向量 + 对应位置编码
        """
        seq_len = x.size(1)
        return x + self.pe[:, :seq_len]


class TransformerLM(nn.Module):
    """
    基于 Transformer Decoder 的单向语言模型。

    训练时输入整句，用因果掩码保证每个位置只能看到它左边的字；
    推理时逐字生成，每次把已生成的字拼起来，预测下一个字。
    """

    def __init__(
        self,
        vocab_size: int,
        d_model: int = 64,
        nhead: int = 4,
        num_layers: int = 2,
        dim_feedforward: int = 256,
        dropout: float = 0.1,
    ):
        """
        参数说明（已针对低配电脑调小）:
            vocab_size: 词表大小（字符级就是不同字符的个数）
            d_model:    隐藏层维度，越大模型越强但越慢
            nhead:      多头注意力的头数，必须能整除 d_model
            num_layers: Transformer 层数
            dim_feedforward: 前馈网络中间层维度
            dropout:    随机丢弃比例，防止过拟合
        """
        super().__init__()
        self.d_model = d_model

        # 1) 字符 ID -> 向量
        self.embedding = nn.Embedding(vocab_size, d_model)

        # 2) 位置编码
        self.pos_encoder = PositionalEncoding(d_model)

        # 3) Transformer Decoder 层
        #    语言模型里没有 Encoder，所以 memory 也填自己，靠 tgt_mask 实现单向
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True,  # 输入格式 [batch, seq, feature]
        )
        self.transformer_decoder = nn.TransformerDecoder(
            decoder_layer, num_layers=num_layers
        )

        # 4) 输出层：向量 -> 词表上每个字的得分 (logits)
        self.fc_out = nn.Linear(d_model, vocab_size)

    @staticmethod
    def generate_causal_mask(seq_len: int, device: torch.device) -> torch.Tensor:
        """
        生成因果掩码 (Causal / Look-ahead Mask)。

        上三角为 -inf，softmax 后变成 0，相当于"看不见"未来位置。
        例如 seq_len=4 时（0=可见，-inf=不可见）:

            0  -inf -inf -inf
            0    0  -inf -inf
            0    0    0  -inf
            0    0    0    0
        """
        mask = torch.triu(
            torch.full((seq_len, seq_len), float("-inf"), device=device),
            diagonal=1,
        )
        return mask

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        前向传播。

        输入 x: [batch_size, seq_len]，每个元素是字符 ID
        输出 logits: [batch_size, seq_len, vocab_size]
        """
        seq_len = x.size(1)
        mask = self.generate_causal_mask(seq_len, x.device)

        # Embedding 后乘以 sqrt(d_model) 是 Transformer 论文里的标准做法
        x = self.embedding(x) * math.sqrt(self.d_model)
        x = self.pos_encoder(x)

        # memory 和 tgt 都用同一个序列；单向性由 mask 保证
        output = self.transformer_decoder(
            tgt=x,
            memory=x,
            tgt_mask=mask,
            memory_mask=mask,
        )

        logits = self.fc_out(output)
        return logits
